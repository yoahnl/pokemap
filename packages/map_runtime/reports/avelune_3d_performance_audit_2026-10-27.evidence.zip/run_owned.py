import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

root = Path(__file__).parent
label, cwd, *command = sys.argv[1:]
temporary = root / ('tmp-' + label)
temporary.mkdir(exist_ok=True)
environment = dict(os.environ, TMPDIR=str(temporary) + '/')

def processes():
    result = {}
    output = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,lstart=,command='], text=True)
    for line in output.splitlines():
        fields = line.strip().split(None, 7)
        if len(fields) == 8:
            result[int(fields[0])] = (int(fields[1]), ' '.join(fields[2:7]), fields[7])
    return result

observed = {}
started = time.monotonic()
with (root / (label + '.log')).open('w') as log:
    runner = subprocess.Popen(command, cwd=cwd, env=environment, stdout=log, stderr=subprocess.STDOUT)
    print(json.dumps({'label': label, 'runner': runner.pid, 'command': command}), flush=True)
    while runner.poll() is None:
        current = processes()
        parents = {runner.pid, *observed}
        for _ in range(6):
            for pid, record in current.items():
                if record[0] in parents:
                    observed[pid] = record
                    parents.add(pid)
        time.sleep(.15)
    result = runner.wait()
time.sleep(.3)
remaining = []
reaped = []
for pid, record in observed.items():
    current = processes().get(pid)
    if current is None or current[1:] != record[1:]:
        continue
    if not any(term in current[2] for term in ['flutter_tester', 'frontend_server', 'flutter_tools.snapshot test']):
        remaining.append(pid)
        continue
    os.kill(pid, signal.SIGTERM)
    time.sleep(.2)
    again = processes().get(pid)
    if again is not None and again[1:] == record[1:]:
        os.kill(pid, signal.SIGKILL)
    reaped.append(pid)
receipt = {'label': label, 'cwd': cwd, 'command': command, 'runner': runner.pid, 'descendants': observed, 'exit': result, 'elapsed_seconds': round(time.monotonic() - started, 3), 'reaped': reaped, 'unresolved': remaining}
(root / (label + '.json')).write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt), flush=True)
print('\n'.join((root / (label + '.log')).read_text().splitlines()[-12:]))
sys.exit(result)
