import 'dart:convert';

import 'package:map_authoring/map_authoring_editing.dart';
import 'package:map_core/map_core.dart';
import 'package:test/test.dart';

void main() {
  test('one spatial rotation retains data proportional to unrelated instances', () {
    final retainedSizes = <int>[];
    for (final count in [10, 100, 1000]) {
      final before = spatialMap(count);
      final after = rotateFirst(before, 1);
      final delta = MapHistoryDelta.between(before, after);
      final beforeSceneBytes = jsonBytes(before.spatialScene!.toJson());
      final afterSceneBytes = jsonBytes(after.spatialScene!.toJson());
      final result = const MapHistoryCoordinator().recordMutation(
        before: before,
        after: after,
        selectionBefore: const MapHistorySelection(),
        undoStack: const [],
        redoStack: const [],
      );
      expect(delta.changedValueCount, 1);
      expect(after.spatialScene!.instances.first.rotationDegrees, 1);
      expect(after.spatialScene!.instances.skip(1), before.spatialScene!.instances.skip(1));
      expect(delta.applyBackward(after), before);
      expect(delta.applyForward(before), after);
      expect(delta.retainedBytes, greaterThanOrEqualTo(beforeSceneBytes + afterSceneBytes));
      expect(result.undoStack, hasLength(1));
      expect((result.undoStack.single as MapHistoryDeltaEntry).checkpoint, isNull);
      retainedSizes.add(delta.retainedBytes);
      print(jsonEncode({
        'probe': 'single_rotation',
        'instances': count,
        'changedValues': delta.changedValueCount,
        'beforeSceneJsonBytes': beforeSceneBytes,
        'afterSceneJsonBytes': afterSceneBytes,
        'deltaRetainedBytes': delta.retainedBytes,
        'entryRetainedBytes': result.undoStack.single.retainedBytes,
      }));
    }
    expect(retainedSizes[1], greaterThan(retainedSizes[0] * 2));
    expect(retainedSizes[2], greaterThan(retainedSizes[1] * 2));
  });

  test('default operation 25 adds two full map JSON checkpoints', () {
    const coordinator = MapHistoryCoordinator();
    var current = spatialMap(1000);
    var undo = <MapHistoryEntry>[];
    for (var operation = 1; operation <= 25; operation++) {
      final before = current;
      final after = rotateFirst(before, operation.toDouble());
      final result = coordinator.recordMutation(
        before: before,
        after: after,
        selectionBefore: const MapHistorySelection(),
        undoStack: undo,
        redoStack: const [],
      );
      undo = result.undoStack;
      current = after;
      final entry = undo.last as MapHistoryDeltaEntry;
      expect(entry.sequence, operation);
      if (operation < 25) {
        expect(entry.checkpoint, isNull);
      } else {
        final checkpoint = entry.checkpoint;
        expect(checkpoint, isNotNull);
        expect(checkpoint!.beforeBytes, utf8.encode(jsonEncode(before.toJson())));
        expect(checkpoint.afterBytes, utf8.encode(jsonEncode(after.toJson())));
        expect(checkpoint.restore(MapHistoryDirection.backward), before);
        expect(checkpoint.restore(MapHistoryDirection.forward), after);
        print(jsonEncode({
          'probe': 'operation_25',
          'instances': 1000,
          'sequence': entry.sequence,
          'undoEntries': undo.length,
          'deltaRetainedBytes': entry.delta.retainedBytes,
          'checkpointBeforeMapJsonBytes': checkpoint.beforeBytes.length,
          'checkpointAfterMapJsonBytes': checkpoint.afterBytes.length,
          'checkpointRetainedBytes': checkpoint.retainedBytes,
          'entryRetainedBytes': entry.retainedBytes,
          'stackRetainedBytes': coordinator.retainedBytes(undo),
        }));
      }
    }
    final unchanged = coordinator.recordMutation(
      before: current,
      after: current,
      selectionBefore: const MapHistorySelection(),
      undoStack: undo,
      redoStack: const [],
    );
    expect(unchanged.undoStack, same(undo));
    expect(unchanged.undoStack.last.sequence, 25);
  });
}

int jsonBytes(Object? value) => utf8.encode(jsonEncode(value)).length;

MapData spatialMap(int count) => MapData(
  id: 'history_probe',
  name: 'Spatial history characterization',
  version: ProjectVersion.v9,
  size: const GridSize(width: 32, height: 32),
  spatialScene: MapSpatialScene(
    width: 32,
    depth: 32,
    instances: List.generate(count, (index) => SpatialModelInstance(
      id: 'instance_$index',
      modelId: 'model',
      position: Model3dVector3(x: index % 32 + .5, y: 0, z: index ~/ 32 + .5),
    )),
  ),
);

MapData rotateFirst(MapData map, double rotation) => const SpatialMapOperations().upsertInstance(
  map,
  map.spatialScene!.instances.first.copyWith(rotationDegrees: rotation),
);
