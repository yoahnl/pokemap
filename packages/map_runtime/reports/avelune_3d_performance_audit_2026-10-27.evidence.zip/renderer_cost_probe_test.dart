import 'dart:convert';
import 'dart:math';

import 'package:flame_3d/components.dart';
import 'package:flame_3d/core.dart';
import 'package:flame_3d/graphics.dart';
import 'package:flame_3d/model.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('actual deferred draw queue costs depend on count and input order', () {
    final rows = <Map<String, Object?>>[];
    for (final count in [128, 512, 2048, 4096]) {
      for (final order in ['sorted', 'reverse', 'shuffled']) {
        final indices = List.generate(count, (i) => i + 1);
        if (order == 'sorted') {
          indices.sort((a, b) => b.compareTo(a));
        } else if (order == 'shuffled') {
          indices.shuffle(Random(17));
        }
        final context = RenderContext3D(_Device());
        context.setCamera(Matrix4.identity(), Matrix4.identity());
        final output = <int>[];
        final objects = [for (final index in indices) _Object(index, output)];
        final matrices = [for (final index in indices) Matrix4.translationValues(index.toDouble(), 0, 0)];
        void submit() {
          output.clear();
          for (var i = 0; i < count; i++) {
            context.submitDraw(objects[i], matrices[i]);
          }
        }
        for (var i = 0; i < 30; i++) {
          submit();
          context.flush();
        }
        final times = <int>[];
        for (var i = 0; i < 21; i++) {
          submit();
          final clock = Stopwatch()..start();
          context.flush();
          times.add(clock.elapsedMicroseconds);
        }
        expect(output, List.generate(count, (i) => count - i));
        expect(context.drawCount, count);
        times.sort();
        rows.add({'objects': count, 'order': order, 'medianUs': times[10], 'p95Us': times[19]});
      }
    }
    print('ACTUAL_FLAME_SORT_PROBE ${jsonEncode(rows)}');
  });

  test('static node graph dependencies are rebuilt on every actual processNodes call', () {
    final nodes = {for (var i = 0; i < 32; i++) i: _Node(i)};
    final model = Model(nodes: nodes, animations: []);
    final state = AnimationState();
    for (var i = 0; i < 100; i++) {
      final processed = model.processNodes(state);
      expect(processed.length, 32);
      expect(processed[31]!.combinedTransform, Matrix4.identity());
    }
    expect(nodes.values.fold(0, (sum, node) => sum + node.dependencyReads), 3200);
    print('STATIC_NODE_GRAPH_PROBE calls=100 nodes=32 dependencyReads=3200 animation=none');
  });
}

class _Device implements GraphicsDevice {
  @override
  dynamic noSuchMethod(Invocation invocation) => throw StateError('GPU unexpected');
}

class _Object extends Object3D {
  _Object(this.index, this.output);
  final int index;
  final List<int> output;
  @override
  void draw(RenderContext context) => output.add(index);
}

class _Node extends ModelNode {
  _Node(int index) : super(name: null, nodeIndex: index, parentNodeIndex: index == 0 ? null : index - 1, transform: Matrix4.identity(), mesh: null, joints: {});
  int dependencyReads = 0;
  @override
  List<int> get dependencies {
    dependencyReads++;
    return super.dependencies;
  }
}
