# Clairbois — Avelune Studio

Premier jet d’un petit projet éditable pour Avelune Studio, avec une grille native de **32 × 32 pixels**. Ce dépôt est indépendant du code de PokeMap.

![Le village de Clairbois dans Avelune Studio](preview/village.png)

## Contenu

- Une carte extérieure de 32 × 26 cases, avec chemins, eau et falaises.
- Une maison de 12 × 10 cases, reliée au village par deux passages.
- Un personnage et un court dialogue.
- Les ressources graphiques, catalogues, collisions et données nécessaires, présents dans ce dépôt.

![La maison de Clairbois dans Avelune Studio](preview/maison.png)

## Ouvrir le projet

1. Cloner ce dépôt ou télécharger son ZIP depuis le bouton **Code** de GitHub, puis l’extraire.
2. Dans Avelune Studio, choisir **Ouvrir un projet** et sélectionner le dossier contenant `project.json`.
3. Ouvrir une carte et utiliser **Tester la carte** pour explorer le projet.

Le projet n’a pas besoin du dossier source PSDK ni du projet personnel du Train pour résoudre ses ressources. Il s’agit d’un projet auteur, pas d’un paquet `.avelunegame` installé dans Player.

Le raccordement de ce dépôt au téléchargement de modèles du créateur de projets Studio reste une étape distincte.

## État du prototype

La composition est un premier jet à retravailler : quelques arbres empiètent encore visuellement sur l’eau. Les captures montrent le rendu réel de cette version dans Studio.

Avant publication de cette copie, une recette automatisée a vérifié le dialogue, les passages village ↔ maison, les collisions de l’eau et des falaises, ainsi que la sauvegarde et la reprise d’un test. Cela ne constitue pas une validation artistique ni une recette manuelle complète dans Player.

## Provenance des ressources

Les ressources proviennent du projet de test PSDK et de préparations graphiques déjà utilisées dans **Le train de 17h42**. Les sources ont été consultées en lecture ; les ressources nécessaires sont embarquées ici.

`asset-provenance.json` conserve les références de source, les préparations et les empreintes des ressources. Les fichiers `assets/.pokemap-assets.json` et `assets/.pokemap-store/` font partie du stockage canonique des assets et doivent être conservés.

Les assets tiers conservent leurs droits d’origine. Ce dépôt ne leur attribue pas une nouvelle licence.
